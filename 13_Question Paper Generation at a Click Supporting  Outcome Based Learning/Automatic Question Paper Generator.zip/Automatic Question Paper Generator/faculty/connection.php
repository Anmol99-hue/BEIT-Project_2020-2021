<?php

$con=mysqli_connect("localhost","root","","qpgs") or die("error creating database");

?>